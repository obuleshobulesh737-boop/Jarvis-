# JARVIS AI
Build: open this folder in Android Studio (Koala+), sync, Run. APK: Build > Build APK(s), or `./gradlew assembleDebug`
-> app/build/outputs/apk/debug/app-debug.apk.  Backend: see backend/server.js (Node 18+): set GEMINI_API_KEY (and optionally APP_TOKEN), `npm start`, deploy behind HTTPS, put the URL in app Settings.
Updates: host backend/update.json.example (edited) over HTTPS, put its URL in Settings > Update feed.
