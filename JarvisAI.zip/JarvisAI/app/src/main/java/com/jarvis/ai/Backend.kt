package com.jarvis.ai

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BackendError(val code: Int) : Exception("HTTP $code")
data class UpdateInfo(val code: Long, val name: String, val url: String, val notes: String)

/** Talks to YOUR backend (backend/server.js). The Gemini key never exists in the app. */
object Backend {
    suspend fun chat(base: String, token: String, hist: List<Msg>, lang: String): String = withContext(Dispatchers.IO) {
        val arr = JSONArray()
        hist.takeLast(12).forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        val body = JSONObject().put("language", lang).put("messages", arr)
        val c = URL(base.trimEnd('/') + "/chat").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            if (token.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $token")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            if (c.responseCode !in 200..299) throw BackendError(c.responseCode)
            val r = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getString("reply")
            if (r.isBlank()) throw BackendError(204)
            r
        } finally { c.disconnect() }
    }
}

object Updater {
    /** Reads a small JSON feed you host over HTTPS. Returns null when already up to date. Never installs anything itself. */
    suspend fun check(ctx: Context, feed: String): UpdateInfo? = withContext(Dispatchers.IO) {
        require(feed.startsWith("https://"))
        val c = URL(feed).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10000; c.readTimeout = 10000
            val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val cur = PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
            if (o.getLong("versionCode") > cur)
                UpdateInfo(o.getLong("versionCode"), o.optString("versionName"), o.getString("url"), o.optString("notes"))
            else null
        } finally { c.disconnect() }
    }
}
