package com.jarvis.ai

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.Application
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.Locale

enum class L(val code: String, val tag: String, val label: String, val englishName: String, val greet: String) {
    EN("en", "en-IN", "English", "English", "Hello, I am JARVIS. How can I help you today?"),
    KN("kn", "kn-IN", "ಕನ್ನಡ", "Kannada", "ನಮಸ್ಕಾರ, ನಾನು ಜಾರ್ವಿಸ್. ನಿಮಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಲಿ?"),
    TE("te", "te-IN", "తెలుగు", "Telugu", "నమస్కారం, నేను జార్విస్. మీకు ఎలా సహాయం చేయగలను?"),
    HI("hi", "hi-IN", "हिन्दी", "Hindi", "नमस्ते, मैं जार्विस हूँ। मैं आपकी कैसे मदद कर सकती हूँ?")
}

enum class St { IDLE, LISTENING, THINKING, SPEAKING }
class Pending(val prompt: String, val run: () -> String)

private val IC = RegexOption.IGNORE_CASE
private val STOP = Regex("stop jarvis|jarvis stop|stop listening|स्टॉप जार्विस|जार्विस रुको|सुनना बंद|बंद करो|స్టాప్ జార్విస్|ఆపు|ಸ್ಟಾಪ್ ಜಾರ್ವಿಸ್|ನಿಲ್ಲಿಸು", IC)
private val HELLO = Regex("(hello|hi|hey) jarvis|हेलो जार्विस|हैलो जार्विस|नमस्ते जार्विस|హలో జార్విస్|ಹಲೋ ಜಾರ್ವಿಸ್", IC)

class JarvisVm(private val app: Application) : AndroidViewModel(app) {
    val msgs = mutableStateListOf<Msg>()
    var status by mutableStateOf(St.IDLE)
    var level by mutableFloatStateOf(0f)
    var lang by mutableStateOf(L.EN)
    var info by mutableStateOf("")
    var pending by mutableStateOf<Pending?>(null)
    var active by mutableStateOf(false)
    var update by mutableStateOf<UpdateInfo?>(null)
    var backendUrl by mutableStateOf("")
    var token by mutableStateOf("")
    var updateUrl by mutableStateOf("")
    var saveHistory by mutableStateOf(true)

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var greeted = false
    private var rec: SpeechRecognizer? = null
    private var fails = 0

    init {
        saveHistory = Store.b(app, "save", true)
        if (saveHistory) msgs.addAll(Store.load(app))
        lang = L.values().firstOrNull { it.code == Store.s(app, "lang", "en") } ?: L.EN
        backendUrl = Store.s(app, "backend"); token = Store.s(app, "token"); updateUrl = Store.s(app, "feed")
        initTts(true)
        if (updateUrl.isNotBlank()) checkUpdate(false)
    }

    // ---------- speech out ----------
    private fun initTts(greet: Boolean) {
        tts = TextToSpeech(app) { s ->
            if (s == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { status = St.SPEAKING } }
                    override fun onDone(id: String?) { main.post { if (status == St.SPEAKING) status = St.IDLE; resume() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { status = St.IDLE; info = "Speech output failed. Try Settings > Troubleshoot > Reset speech engines." } }
                })
                if (greet && !greeted) { greeted = true; speak(lang.greet, lang) }
            } else info = "Text-to-speech could not start. Install or enable 'Speech Services by Google'."
        }
    }

    private fun applyVoice(l: L): Boolean {
        val t = tts ?: return false
        val loc = Locale.forLanguageTag(l.tag)
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            info = "${l.englishName} voice is not installed. Settings > Install voice data."
            return false
        }
        runCatching { // prefer a voice that identifies as female; otherwise default voice with higher pitch
            t.voices?.firstOrNull { it.locale.language == loc.language && it.name.contains("female", true) }?.let { t.voice = it }
        }
        t.setPitch(1.12f); t.setSpeechRate(0.97f)
        return true
    }

    private fun speak(text: String, l: L = L.EN): Boolean {
        if (!ttsReady || !applyVoice(l)) return false
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u${System.nanoTime()}")
        return true
    }

    private fun persist() { if (saveHistory) Store.save(app, msgs.toList()) }

    private fun say(text: String, l: L = L.EN) {
        msgs.add(Msg("model", text)); persist(); status = St.IDLE
        if (!speak(text, l)) resume()
    }

    // ---------- start / stop listening ----------
    fun start() {
        if (active && status == St.LISTENING) return
        active = true; fails = 0; info = ""; listen()
    }

    fun stop() {
        active = false
        main.removeCallbacksAndMessages(null)
        runCatching { rec?.cancel() }
        tts?.stop(); level = 0f; status = St.IDLE
    }

    private fun resume() {
        if (!active) return
        main.postDelayed({ if (active && status == St.IDLE) listen() }, 500)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            stop(); info = "No speech recognition service. Install/enable 'Speech Services by Google'."; return
        }
        info = ""
        runCatching { rec?.destroy() }
        rec = SpeechRecognizer.createSpeechRecognizer(app).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { level = 0f }
                override fun onError(e: Int) { level = 0f; status = St.IDLE; recFail(e) }
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) { status = St.IDLE; recFail(7) } else { fails = 0; handle(t) }
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.tag)
        status = St.LISTENING
        rec?.startListening(i)
    }

    /** Recoverable errors (silence, busy/client glitch) retry up to 3 times; anything else stops with a clear message. */
    private fun recFail(e: Int) {
        if (!active) { info = recError(e); return }
        when (e) {
            5, 6, 7, 8 -> {
                if (e == 5 || e == 8) { runCatching { rec?.destroy() }; rec = null }
                if (++fails >= 3) { stop(); info = "Stopped listening after several attempts. Tap Start to resume." } else resume()
            }
            else -> { stop(); info = recError(e) }
        }
    }

    private fun recError(e: Int) = when (e) {
        7 -> "I didn't catch that."
        6 -> "No speech detected."
        9 -> "Microphone permission is missing. Allow it in app settings."
        1, 2 -> "Speech recognition needs internet (or an offline ${lang.englishName} language pack)."
        12, 13 -> "${lang.englishName} speech recognition is unavailable. Download its language pack in Google app settings."
        3 -> "Audio problem. Close other apps using the microphone."
        else -> "Speech recognition error ($e)."
    }

    // ---------- commands ----------
    fun handle(raw: String) {
        level = 0f
        val t = raw.replace(Regex("(?<=\\d)[ -](?=\\d)"), "").trim() // "98450 12345" -> "9845012345"
        msgs.add(Msg("user", raw)); persist()
        if (STOP.containsMatchIn(t)) { stop(); pending = null; say("Okay, I've stopped listening. Tap Start when you need me."); return }
        pending?.let { p ->
            pending = null
            val no = Regex("\\b(no|cancel|don't)\\b|नहीं|रद्द|ಇಲ್ಲ|ಬೇಡ|వద్దు|కాదు", IC)
            val yes = Regex("\\b(yes|yeah|yep|confirm|ok|okay|sure|go ahead)\\b|हाँ|हां|ठीक|ಹೌದು|ಸರಿ|అవును|సరే", IC)
            if (!no.containsMatchIn(t) && yes.containsMatchIn(t)) { say(p.run()); return }
            say("Cancelled."); return
        }
        if (local(t)) return
        askAi()
    }

    private fun local(t: String): Boolean {
        if (HELLO.containsMatchIn(t)) { say(lang.greet, lang); return true }
        if (Regex("youtube|यूट्यूब|యూట్యూబ్|ಯೂಟ್ಯೂಬ್", IC).containsMatchIn(t) &&
            Regex("play|search|song|music|गाना|चलाओ|बजाओ|ಹಾಡು|పాట|ప్లే|ಪ್ಲೇ", IC).containsMatchIn(t)) {
            var q = t.replace(Regex("\\b(open|play|search|on|in|youtube|for|me|the)\\b|यूट्यूब|యూట్యూబ్|ಯೂಟ್ಯೂಬ್", IC), " ")
                .replace(Regex("\\s+"), " ").trim()
            if (q.isEmpty()) q = "music"
            say(if (launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))))
                "Searching YouTube for $q." else "I couldn't open YouTube."); return true
        }
        Regex("(?:navigate to|directions to|take me to|route to)\\s+(.+)", IC).find(t)?.let { m ->
            say("Opening Maps for ${m.groupValues[1]}."); openMaps(m.groupValues[1]); return true
        }
        Regex("\\b(?:message|sms|text)\\s+(\\+?\\d{7,15})\\s+(?:saying\\s+|that\\s+)?(.+)|मैसेज\\s*(\\+?\\d{7,15})\\s+(.+)", IC).find(t)?.let { m ->
            val num = m.groupValues[1].ifEmpty { m.groupValues[3] }; val body = m.groupValues[2].ifEmpty { m.groupValues[4] }
            return ask("Prepare a message to $num: \"$body\"? Say yes to open it in your messaging app. You will still press Send yourself.") {
                launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num")).putExtra("sms_body", body))
                "Message is ready. Please review it and press Send."
            }
        }
        Regex("(?:\\bcall\\b|\\bdial\\b|कॉल|ಕರೆ|కాల్)\\s*(\\+?\\d{7,15})", IC).find(t)?.let { m ->
            val num = m.groupValues[1]
            return ask("Call $num? Say yes to open the dialer. You will still press the call button yourself.") {
                launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))); "Dialer is open."
            }
        }
        if (Regex("notification|नोटिफिकेशन|सूचना|ಅಧಿಸೂಚನೆ|నోటిఫికేషన్", IC).containsMatchIn(t)) { say(readNotifs(), lang); return true }
        if (Regex("\\bgo back\\b|पीछे जाओ", IC).containsMatchIn(t)) return screen("press Back", AccessibilityService.GLOBAL_ACTION_BACK)
        if (Regex("\\bgo home\\b|होम जाओ", IC).containsMatchIn(t)) return screen("go to the Home screen", AccessibilityService.GLOBAL_ACTION_HOME)
        if (Regex("\\bopen\\b|खोल|తెరు|తెర|ತೆರೆ", IC).containsMatchIn(t)) {
            val apps = listOf<Triple<String, Regex, () -> Unit>>(
                Triple("YouTube", Regex("youtube|यूट्यूब|యూట్యూబ్|ಯೂಟ್ಯೂಬ್", IC), { openYouTube() }),
                Triple("WhatsApp", Regex("whatsapp|व्हाट्सएप|వాట్సాప్|ವಾಟ್ಸಾಪ್", IC), { openWhatsApp() }),
                Triple("Chrome", Regex("chrome|क्रोम|క్రోమ్|ಕ್ರೋಮ್", IC), { openChrome() }),
                Triple("Maps", Regex("\\bmaps?\\b|मैप|మ్యాప్స్|ನಕ್ಷೆ|ಮ್ಯಾಪ್", IC), { openMaps(null) }),
                Triple("Settings", Regex("settings?|सेटिंग|సెట్టింగ్|ಸೆಟ್ಟಿಂಗ್", IC), { openSettings() })
            )
            apps.firstOrNull { it.second.containsMatchIn(t) }?.let { say("Opening ${it.first}."); it.third(); return true }
        }
        return false
    }

    private fun ask(prompt: String, run: () -> String): Boolean { pending = Pending(prompt, run); say(prompt); return true }

    private fun screen(what: String, action: Int): Boolean {
        val s = JarvisAccessibilityService.instance
        if (s == null) { say("Screen control is off. Enable JARVIS in Accessibility settings first."); return true }
        return ask("Do you want me to $what?") { if (s.performGlobalAction(action)) "Done." else "That action failed." }
    }

    private fun readNotifs(): String {
        if (!notifEnabled()) return "Notification access is off. Enable it in Settings."
        val l = NotifStore.recent()
        return if (l.isEmpty()) "No notifications captured yet." else l.takeLast(3).joinToString(" . ")
    }

    // ---------- AI via backend ----------
    private fun validBackend(u: String) = u.startsWith("https://") || u.startsWith("http://10.0.2.2") || u.startsWith("http://localhost")

    private fun askAi() {
        if (backendUrl.isBlank()) { info = "Set your backend URL in Settings."; say("Please set up my backend in settings."); return }
        status = St.THINKING; info = ""
        viewModelScope.launch {
            try {
                var reply: String? = null
                for (attempt in 1..2) { // one automatic retry for network hiccups
                    try { reply = Backend.chat(backendUrl, token, msgs.toList(), lang.englishName); break }
                    catch (e: IOException) { if (attempt == 2) throw e; delay(1500) }
                }
                say(reply ?: "", lang)
            } catch (e: BackendError) {
                status = St.IDLE
                info = when (e.code) {
                    401 -> "Backend rejected the app token. Check Settings."
                    429 -> "Too many requests. Wait a minute."
                    204, 502 -> "The AI service returned no answer. Try again."
                    else -> "Backend error (${e.code})."
                }
                if (active) stop()
            } catch (e: IOException) {
                status = St.IDLE; info = "Can't reach the backend. Check internet and the URL in Settings."; if (active) stop()
            } catch (e: Exception) {
                status = St.IDLE; info = "Unexpected reply from the backend."; if (active) stop()
            }
        }
    }

    // ---------- launching apps (only standard Android intents) ----------
    private fun launch(i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); app.startActivity(i); true
    } catch (e: ActivityNotFoundException) { info = "No app found for that action."; false }
      catch (e: SecurityException) { info = "Android blocked that action."; false }

    private fun openPkg(pkg: String, url: String) {
        val i = app.packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) launch(i) else { info = "App not installed; opening the website."; launch(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
    fun openYouTube() = openPkg("com.google.android.youtube", "https://www.youtube.com")
    fun openWhatsApp() = openPkg("com.whatsapp", "https://web.whatsapp.com")
    fun openChrome() {
        val u = Uri.parse("https://www.google.com")
        if (!launch(Intent(Intent.ACTION_VIEW, u).setPackage("com.android.chrome"))) launch(Intent(Intent.ACTION_VIEW, u))
    }
    fun openMaps(q: String?) {
        val u = Uri.parse(if (q == null) "geo:0,0" else "geo:0,0?q=" + Uri.encode(q))
        if (!launch(Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.apps.maps"))) launch(Intent(Intent.ACTION_VIEW, u))
    }
    fun openSettings() { launch(Intent(Settings.ACTION_SETTINGS)) }
    fun openUrl(u: String) { if (u.startsWith("https://")) launch(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
    fun openAppInfo() { launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))) }
    fun openNotifAccess() { launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
    fun openA11y() { launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    fun installVoices() { launch(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }

    // ---------- settings / privacy / recovery ----------
    fun setLanguage(l: L) { lang = l; Store.putS(app, "lang", l.code); info = ""; applyVoice(l) }
    fun saveBackend(url: String, tok: String) {
        val u = url.trim()
        if (u.isNotEmpty() && !validBackend(u)) { info = "Backend URL must start with https://"; return }
        backendUrl = u; token = tok.trim(); Store.putS(app, "backend", u); Store.putS(app, "token", token); info = "Backend saved."
    }
    fun saveFeed(url: String) {
        val u = url.trim()
        if (u.isNotEmpty() && !u.startsWith("https://")) { info = "Update feed must start with https://"; return }
        updateUrl = u; Store.putS(app, "feed", u)
    }
    fun checkUpdate(manual: Boolean) {
        if (updateUrl.isBlank()) { if (manual) info = "Set an update feed URL in Settings first."; return }
        viewModelScope.launch {
            try {
                val u = Updater.check(app, updateUrl); update = u
                if (manual) info = if (u == null) "You're on the latest version." else ""
            } catch (e: Exception) { if (manual) info = "Couldn't check for updates (needs a valid https feed)." }
        }
    }
    fun setSave(v: Boolean) { saveHistory = v; Store.putB(app, "save", v); if (v) persist() else Store.clearHistory(app) }
    fun clearHistory() { msgs.clear(); Store.clearHistory(app) }
    fun resetEngines() {
        stop(); runCatching { rec?.destroy() }; rec = null
        runCatching { tts?.shutdown() }; ttsReady = false; initTts(false); info = "Speech engines reset."
    }
    fun resetAll() {
        resetEngines(); Store.resetAll(app); msgs.clear()
        backendUrl = ""; token = ""; updateUrl = ""; update = null; lang = L.EN; saveHistory = true; info = "App data reset."
    }
    fun confirm(yes: Boolean) { handle(if (yes) "yes" else "cancel") }
    fun notifEnabled() = NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)
    fun a11yEnabled() = JarvisAccessibilityService.instance != null

    fun diagnostics(): List<String> {
        val mic = ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val base = listOf(
            "Microphone permission: " + if (mic) "OK" else "MISSING",
            "Speech recognition service: " + if (SpeechRecognizer.isRecognitionAvailable(app)) "OK" else "NOT FOUND",
            "Text-to-speech engine: " + if (ttsReady) "OK" else "NOT READY"
        )
        val voices = L.values().map { l ->
            val r = tts?.isLanguageAvailable(Locale.forLanguageTag(l.tag)) ?: -2
            "Voice ${l.englishName}: " + if (r >= TextToSpeech.LANG_AVAILABLE) "OK" else "NOT INSTALLED"
        }
        return base + voices + listOf(
            "Backend URL: " + if (backendUrl.isBlank()) "NOT SET" else "set",
            "Notification access: " + if (notifEnabled()) "ON" else "OFF",
            "Screen control: " + if (a11yEnabled()) "ON" else "OFF"
        )
    }

    override fun onCleared() { main.removeCallbacksAndMessages(null); rec?.destroy(); tts?.shutdown() }
}
