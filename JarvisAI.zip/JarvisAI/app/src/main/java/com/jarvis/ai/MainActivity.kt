package com.jarvis.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Bg = Color(0xFF05080F)
private val Blue = Color(0xFF29B6FF)
private val Purple = Color(0xFF7C8CFF)
private val Green = Color(0xFF4DD0E1)
private val Muted = Color(0xFF8FA3B8)

enum class Page { HOME, SETTINGS, PRIVACY, HELP }

class MainActivity : ComponentActivity() {
    private val vm: JarvisVm by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Color(0xFF0D1422))) {
                var page by remember { mutableStateOf(Page.HOME) }
                BackHandler(page != Page.HOME) { page = Page.HOME }
                when (page) {
                    Page.HOME -> Home(vm) { page = it }
                    Page.SETTINGS -> SettingsPage(vm, { page = Page.HOME }) { page = it }
                    Page.PRIVACY -> PrivacyPage(vm) { page = Page.HOME }
                    Page.HELP -> HelpPage(vm) { page = Page.HOME }
                }
            }
        }
    }
    /** The microphone is never used in the background: leaving the app stops listening. */
    override fun onStop() { super.onStop(); vm.stop() }
}

@Composable
fun Orb(status: St, level: Float, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(0.95f, 1.05f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val lv by animateFloatAsState(level, label = "lv")
    val col = when (status) { St.LISTENING -> Blue; St.THINKING -> Purple; St.SPEAKING -> Green; St.IDLE -> Blue.copy(alpha = 0.55f) }
    Canvas(modifier) {
        val c = center; val r = size.minDimension / 2f
        val k = pulse + lv * 0.12f
        drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.5f), Color.Transparent), center = c, radius = r * k), radius = r * k, center = c)
        drawCircle(col, radius = r * 0.62f * k, center = c, style = Stroke(3f))
        drawCircle(col.copy(alpha = 0.3f), radius = r * 0.42f * k, center = c)
        rotate(rot, c) {
            for (i in 0 until 3) drawArc(col, i * 120f, 70f, false, Offset(c.x - r * 0.8f, c.y - r * 0.8f), Size(r * 1.6f, r * 1.6f), style = Stroke(6f, cap = StrokeCap.Round))
        }
        rotate(-rot * 1.5f, c) {
            for (i in 0 until 48) rotate(i * 7.5f, c) {
                drawLine(col.copy(alpha = 0.6f), Offset(c.x, c.y - r * 0.92f), Offset(c.x, c.y - r * 0.98f), 3f)
            }
        }
    }
}

@Composable
fun Home(vm: JarvisVm, go: (Page) -> Unit) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.start() else vm.info = "Microphone permission denied. Allow it in Android app settings."
    }
    fun startVoice() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.start()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("J.A.R.V.I.S", color = Blue, fontSize = 20.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { go(Page.SETTINGS) }) { Text("⚙ Settings", color = Blue) }
        }
        vm.update?.let { u ->
            Row(Modifier.fillMaxWidth().background(Color(0xFF10263A), RoundedCornerShape(10.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Update ${u.name} available", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.openUrl(u.url) }) { Text("Download") }
            }
        }
        Orb(vm.status, vm.level, Modifier.size(200.dp).padding(8.dp).clickable { if (vm.active) vm.stop() else startVoice() })
        Text(
            when {
                vm.status == St.LISTENING -> "Listening… say “Stop JARVIS” to stop"
                vm.status == St.THINKING -> "Thinking…"
                vm.status == St.SPEAKING -> "Speaking…"
                vm.active -> "Active"
                else -> "Stopped — tap Start"
            }, color = Muted, fontSize = 13.sp
        )
        if (vm.info.isNotEmpty()) Text(vm.info, color = Color(0xFFFF8A80), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
        val ls = rememberLazyListState()
        LaunchedEffect(vm.msgs.size) { if (vm.msgs.isNotEmpty()) ls.animateScrollToItem(vm.msgs.size - 1) }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), state = ls, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.msgs) { m ->
                val u = m.role == "user"
                Box(Modifier.fillMaxWidth(), contentAlignment = if (u) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, fontSize = 14.sp,
                        modifier = Modifier.widthIn(max = 300.dp).background(if (u) Color(0xFF12304A) else Color(0xFF171A33), RoundedCornerShape(12.dp)).padding(10.dp))
                }
            }
        }
        vm.pending?.let {
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.confirm(true) }, modifier = Modifier.weight(1f)) { Text("Confirm") }
                OutlinedButton(onClick = { vm.confirm(false) }, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val pad = PaddingValues(2.dp)
            OutlinedButton({ vm.openYouTube() }, Modifier.weight(1f), contentPadding = pad) { Text("YouTube", fontSize = 10.sp, maxLines = 1) }
            OutlinedButton({ vm.openWhatsApp() }, Modifier.weight(1f), contentPadding = pad) { Text("WhatsApp", fontSize = 10.sp, maxLines = 1) }
            OutlinedButton({ vm.openChrome() }, Modifier.weight(1f), contentPadding = pad) { Text("Chrome", fontSize = 10.sp, maxLines = 1) }
            OutlinedButton({ vm.openMaps(null) }, Modifier.weight(1f), contentPadding = pad) { Text("Maps", fontSize = 10.sp, maxLines = 1) }
            OutlinedButton({ vm.openSettings() }, Modifier.weight(1f), contentPadding = pad) { Text("Settings", fontSize = 10.sp, maxLines = 1) }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { startVoice() }, enabled = !vm.active, modifier = Modifier.weight(1f).height(56.dp)) { Text("🎤  Start", fontSize = 16.sp) }
            OutlinedButton(onClick = { vm.stop() }, enabled = vm.active, modifier = Modifier.weight(1f).height(56.dp)) { Text("■  Stop", fontSize = 16.sp) }
        }
    }
}

@Composable
fun PageFrame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Back", color = Blue) }
            Text(title, color = Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable
fun SettingsPage(vm: JarvisVm, back: () -> Unit, go: (Page) -> Unit) {
    var url by remember { mutableStateOf(vm.backendUrl) }
    var tok by remember { mutableStateOf(vm.token) }
    var feed by remember { mutableStateOf(vm.updateUrl) }
    PageFrame("Settings", back) {
        Text("Language (speech input and replies)", color = Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            L.values().forEach { l -> FilterChip(selected = vm.lang == l, onClick = { vm.setLanguage(l) }, label = { Text(l.label, fontSize = 12.sp) }) }
        }
        TextButton(onClick = { vm.installVoices() }) { Text("Install voice data") }
        Text("AI backend (holds the Gemini key; see backend/README)", color = Muted, fontSize = 12.sp)
        OutlinedTextField(url, { url = it }, singleLine = true, label = { Text("Backend URL (https://…)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(tok, { tok = it }, singleLine = true, label = { Text("App token (optional)") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Button(onClick = { vm.saveBackend(url, tok) }) { Text("Save backend") }
        Text("Updates", color = Muted, fontSize = 12.sp)
        OutlinedTextField(feed, { feed = it }, singleLine = true, label = { Text("Update feed URL (https://…/update.json)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.saveFeed(feed) }) { Text("Save") }
            OutlinedButton(onClick = { vm.saveFeed(feed); vm.checkUpdate(true) }) { Text("Check now") }
        }
        Text("Optional permissions", color = Muted, fontSize = 12.sp)
        OutlinedButton(onClick = { vm.openNotifAccess() }) { Text("Notification access: " + if (vm.notifEnabled()) "ON" else "OFF") }
        OutlinedButton(onClick = { vm.openA11y() }) { Text("Screen control: " + if (vm.a11yEnabled()) "ON" else "OFF") }
        if (vm.info.isNotEmpty()) Text(vm.info, color = Color(0xFFFF8A80), fontSize = 13.sp)
        OutlinedButton(onClick = { go(Page.PRIVACY) }) { Text("Privacy settings") }
        OutlinedButton(onClick = { go(Page.HELP) }) { Text("Troubleshooting & reset") }
    }
}

@Composable
fun PrivacyPage(vm: JarvisVm, back: () -> Unit) {
    PageFrame("Privacy", back) {
        Text("• Only the text of your conversation (last 12 messages) is sent to YOUR backend, which forwards it to Google Gemini.\n" +
            "• Never sent: notifications, contacts, screen content, call or message targets.\n" +
            "• Voice recognition uses Android’s speech service (may be processed by Google, per your device settings).\n" +
            "• The microphone is used only while you press Start and the app is on screen. Leaving the app stops it.\n" +
            "• History, settings and tokens are stored encrypted on this phone only.\n" +
            "• Calls and messages are never sent without your confirmation, and you still press Call/Send yourself.\n" +
            "• Notification access and screen control are optional and off until you enable them in Android settings.",
            color = Color.White, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Save conversation history", color = Color.White, modifier = Modifier.weight(1f))
            Switch(checked = vm.saveHistory, onCheckedChange = { vm.setSave(it) })
        }
        OutlinedButton(onClick = { vm.clearHistory() }) { Text("Delete conversation history") }
        OutlinedButton(onClick = { vm.openAppInfo() }) { Text("Manage Android permissions") }
    }
}

@Composable
fun HelpPage(vm: JarvisVm, back: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    val d = remember(tick) { vm.diagnostics() }
    PageFrame("Troubleshooting", back) {
        d.forEach { Text(it, color = if (it.endsWith("OK") || it.endsWith("ON") || it.endsWith("set")) Color.White else Color(0xFFFFB74D), fontSize = 13.sp) }
        Button(onClick = { tick++ }) { Text("Re-run checks") }
        OutlinedButton(onClick = { vm.resetEngines(); tick++ }) { Text("Reset speech engines") }
        OutlinedButton(onClick = { vm.installVoices() }) { Text("Install voice data") }
        OutlinedButton(onClick = { vm.openAppInfo() }) { Text("Open app permissions") }
        OutlinedButton(onClick = { vm.resetAll(); tick++ }) { Text("Reset all app data") }
        Text("JARVIS cannot scan for or remove viruses. For malware protection use Google Play Protect (Play Store → profile → Play Protect) " +
            "and install apps and updates only from sources you trust.", color = Muted, fontSize = 12.sp)
    }
}
