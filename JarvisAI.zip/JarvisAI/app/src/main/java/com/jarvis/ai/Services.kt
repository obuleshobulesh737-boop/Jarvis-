package com.jarvis.ai

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CopyOnWriteArrayList

/** In-memory only (never written to disk, never sent to Gemini). */
object NotifStore {
    private val items = CopyOnWriteArrayList<String>()
    fun push(s: String) { items.add(s); while (items.size > 10) items.removeAt(0) }
    fun recent(): List<String> = items.toList()
}

class JarvisNotificationService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (x: Exception) { sbn.packageName }
        NotifStore.push("$app: $title. $text")
    }
}

/** Can only press Back/Home. Does not read the screen. Used only after a spoken/tapped confirmation. */
class JarvisAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    companion object { @Volatile var instance: JarvisAccessibilityService? = null }
}
