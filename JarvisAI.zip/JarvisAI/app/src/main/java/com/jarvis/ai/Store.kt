package com.jarvis.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val role: String, val text: String) // role: "user" | "model"

/** Settings, backend token and history live in AES-256 encrypted prefs, on-device only. */
object Store {
    @Volatile private var cached: SharedPreferences? = null
    private fun p(c: Context): SharedPreferences = cached ?: synchronized(this) {
        cached ?: run {
            val ctx = c.applicationContext
            val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                ctx, "jarvis_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.also { cached = it }
    }
    fun s(c: Context, k: String, d: String = ""): String = runCatching { p(c).getString(k, d) ?: d }.getOrDefault(d)
    fun putS(c: Context, k: String, v: String) { runCatching { p(c).edit().putString(k, v).apply() } }
    fun b(c: Context, k: String, d: Boolean): Boolean = runCatching { p(c).getBoolean(k, d) }.getOrDefault(d)
    fun putB(c: Context, k: String, v: Boolean) { runCatching { p(c).edit().putBoolean(k, v).apply() } }
    fun load(c: Context): List<Msg> = try {
        val a = JSONArray(s(c, "hist", "[]"))
        List(a.length()) { val o = a.getJSONObject(it); Msg(o.getString("r"), o.getString("t")) }
    } catch (e: Exception) { emptyList() }
    fun save(c: Context, l: List<Msg>) {
        val a = JSONArray()
        l.takeLast(200).forEach { a.put(JSONObject().put("r", it.role).put("t", it.text)) }
        putS(c, "hist", a.toString())
    }
    fun clearHistory(c: Context) { runCatching { p(c).edit().remove("hist").apply() } }
    fun resetAll(c: Context) { runCatching { p(c).edit().clear().apply() } }
}
