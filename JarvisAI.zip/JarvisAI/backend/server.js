import http from 'node:http';
const { GEMINI_API_KEY, APP_TOKEN = '', GEMINI_MODEL = 'gemini-2.5-flash', PORT = 8787 } = process.env;
if (!GEMINI_API_KEY) { console.error('Set GEMINI_API_KEY'); process.exit(1); }
const LANGS = ['English', 'Kannada', 'Telugu', 'Hindi'];
const hits = new Map();
const limited = (ip) => {
  const now = Date.now();
  const h = (hits.get(ip) || []).filter((t) => now - t < 60000);
  h.push(now); hits.set(ip, h);
  return h.length > 30; // 30 requests / minute / IP
};
http.createServer(async (req, res) => {
  const send = (c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  if (req.method !== 'POST' || req.url !== '/chat') return send(404, { error: 'not found' });
  if (APP_TOKEN && req.headers.authorization !== `Bearer ${APP_TOKEN}`) return send(401, { error: 'unauthorized' });
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0];
  if (limited(ip)) return send(429, { error: 'rate limited' });
  let raw = '';
  for await (const c of req) { raw += c; if (raw.length > 32768) return send(413, { error: 'too large' }); }
  try {
    const body = JSON.parse(raw);
    const language = LANGS.includes(body.language) ? body.language : 'English';
    const contents = (body.messages || []).slice(-12).map((m) => ({
      role: m.role === 'user' ? 'user' : 'model', parts: [{ text: String(m.text).slice(0, 2000) }] }));
    const system = `You are JARVIS, a friendly female voice assistant. Always reply in ${language}. ` +
      'Keep replies under 4 short sentences, plain text, no markdown or emojis.';
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents }) });
    if (!r.ok) return send(502, { error: 'upstream ' + r.status });
    const j = await r.json();
    send(200, { reply: j.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || '' });
  } catch { send(400, { error: 'bad request' }); }
}).listen(PORT, () => console.log('JARVIS backend on :' + PORT));
